/*
    Daniel Davis
    CSCI 4010
    25 November 2019
 */

package edu.apsu.csci.orderandchaos;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

public class AboutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.about_app);
    }
}
